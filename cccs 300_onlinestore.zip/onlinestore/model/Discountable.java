package com.onlinestore.model;

public interface Discountable {
    void applyDiscount(double percentage);
}
